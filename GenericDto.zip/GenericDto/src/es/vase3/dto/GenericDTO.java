package es.vase3.dto;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class GenericDTO<G extends AttributeGroup> implements Serializable {

    private static final long serialVersionUID = 1L;

    private Class<G> attributeGroup;

    private Map<Attribute<G, ?>, Object> attributes = new LinkedHashMap<Attribute<G, ?>, Object>();

    private GenericDTO(Class<G> attributeGroup) {
        this.attributeGroup = attributeGroup;
    }

    public static <B extends AttributeGroup> GenericDTO<B> getInstance(
            Class<B> clazz) {
        return new GenericDTO<B>(clazz);
    }

    public <T> GenericDTO<G> set(Attribute<G, T> identifier, T value) {

        attributes.put(identifier, value);

        return this;
    }

    public <T> GenericDTO<G> set(String identifier, T value) {

    	Attribute<G, T> attribute = Attribute.getInstance(identifier);
        this.set(attribute, value);

        return this;
    }
    
    public <T> T get(Attribute<G, T> identifier) {

        @SuppressWarnings("unchecked")
        T theValue = (T) attributes.get(identifier);

        return theValue;
    }

    @SuppressWarnings("unchecked")
	public <T> T get(String identifier) {

		Set <Attribute<G, ?>> attributes = this.getAttributes();
    	Iterator<Attribute<G, ?>> i = attributes.iterator();
    	while(i.hasNext()){
    		Attribute<G, ?> currentAttribute = (Attribute<G, ?>) i.next();
    		String attributeName = currentAttribute.toString();
    		if( attributeName.equalsIgnoreCase(identifier)){
				T theValue = (T) this.get(currentAttribute);
    	        return theValue;		
    		}
    	}
    	return null;
    }
    
    public <T> T remove(Attribute<G, T> identifier) {

        @SuppressWarnings("unchecked")
        T theValue = (T) attributes.remove(identifier);

        return theValue;
    }

    public void clear() {
        attributes.clear();
    }

    public int size() {
        return attributes.size();
    }

    public Set<Attribute<G, ?>> getAttributes() {
        return attributes.keySet();
    }

    public boolean contains(Attribute<G, ?> identifier) {

        return attributes.containsKey(identifier);
    }

    @Override
    public String toString() {
        return attributeGroup.getSimpleName() + " [" + attributes + "]";
    }

    // equals(), hashCode() ...
}
