package es.vase3.dto;

public interface AttributeGroup {

}
